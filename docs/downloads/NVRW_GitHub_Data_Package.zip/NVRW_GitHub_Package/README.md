# North Valley Recreation and Wellness

This repository contains the complete synthetic NVRW data package used in *Data Science in Practice: A Guide for Capstone, Consulting, and Client-Based Work*.

## Start here

1. Read [`data/nvrw/README.md`](data/nvrw/README.md).
2. Review [`data/nvrw/data_dictionary.csv`](data/nvrw/data_dictionary.csv).
3. Use `data/nvrw/raw/` for data-quality and cleaning exercises.
4. Use `data/nvrw/clean/` to reproduce the worked analyses.
5. Use `data/nvrw/derived/` for modelling, forecasting, projections, and CLV exercises.
6. Open [`data/nvrw/NVRW_Analysis_Examples.xlsx`](data/nvrw/NVRW_Analysis_Examples.xlsx) for the Excel demonstration.
7. Run the scripts in `scripts/` from the repository root.
8. Follow `powerbi/NVRW_Power_BI_Guide.md` to create the Power BI model.

## Contents

- `data/nvrw/raw/`: source-like CSV files containing documented teaching issues
- `data/nvrw/clean/`: standardized CSV files
- `data/nvrw/derived/`: analysis-ready summaries and model files
- `scripts/`: deterministic generator and reproducible R demonstrations
- `powerbi/`: model, relationship, and DAX guidance
- `figures/`: reusable diagrams and an Excel screenshot
- `documentation/`: complete project synthesis in R Markdown

All data are synthetic. No real personal, client, or organizational information is included.

Copyright © [Year] [Copyright holder]. All rights reserved. Update `LICENSE.md` before public release if broader reuse permission is intended.
